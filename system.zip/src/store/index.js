import { createContext } from "react";

export const statt = createContext()

export default statt;