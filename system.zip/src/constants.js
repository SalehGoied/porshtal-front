// src/constants.js
export const BASE_URL = "http://66.45.251.54/~porshtal/porshtal-backend/public/api";
